## 内外网情况说明
## 前端对接模式

### 对接模式说明

直连模式：三方前端拉流直接请求ICC服务器；<br>
代理模式：三方web服务器代理，三方前端则请求三方web服务器，再由三方web服务器中转到ICC服务器上，此模式一般是解决wss证书不安全问题；<br>

### 方案介绍

|  前端对接模式   | 说明 | 
| ------------ | ------------ |
|  ws直连模式 | 三方前端必须是http,三方前端开通端口是9100、9320  |
|  wss直连模式 | 三方前端必须是https,三方前端开通端口是9102、9322  |
|  wss代理模式 | 三方前端必须是https, 三方web服务器需开通端口是9100、9320 （一般ICC平台证书非安全下使用，ICC平台web端非插件模式是此模式），会占用三方web服务器宽带|
|  ws代理模式 |  三方前端必须是https,三方web服务器需开通端口是9100、9320;<br>一般ws直连只需开通前端到ICC平台即可，不推荐ws代理，会占用三方web服务器宽带|


### 推荐说明

能直连尽量不选择代理；<br>
代理虽会解决证书不安全问题，但也会影响三方web服务器宽带；<br>
存在分布式情况且是wss，如果不能为每个节点提供安全证书，则使用代理。缺点是分布式服务器均占用三方web服务宽带，失去分布式的意义。<br>



## 内外网概述

1、什么情况下需要配置内外网映射？

	当三方平台需要同时支持内网与外网实时预览、录像回放、语音对讲，三方前端需根据前端所在网络选择相应的流地址进行播放，避免出现外网播放内网地址，导致网络超时。

2、内外网映射需要开通哪些端口

**前端**

|  前端对接模式  |  端口列表 | 说明 | 
| ------------ | ------------ |------------ |
|  ws直连模式 | 9100、9320  | 实时流：9100、录像回放：9320；<br>前端需开通此端口列表  |
|  wss直连模式 | 9102、9322  | 实时流：9102、录像回放：9322;<br>需三方提供安全证书导入平台<br>前端需开通此端口列表  |
|  wss代理模式 | 9100、9320  | 实时流：9100、录像回放：9320;<br>三方web服务器需开通此端口列表；ICC有安全证书情况下不推荐使用，会占用三方web服务器宽带  |
|  ws代理模式 | 9100、9320  | 实时流：9100、录像回放：9320;<br>三方web服务器需开通此端口列表;<br>一般ws直连只需打通前端到ICC平台即可，不推荐ws代理，会占用三方web服务器宽带。  |

**后端**

三方后端服务需调API接口获取RTSP流地址（实时预览、录像回放），只需开通443端口



## 安全证书导入平台

>第一步：第三方提供安全证书，证书格式需ngnix格式；证书参考<a href="https://open-icc.dahuatech.com/download/others/httpsconfig/nginx证书.rar">示例说明</a><br>
>第二步：ssh登录ICC后台，切root用户操作
>第三步：同步证书到MTS/SS服务命令

- 实时预览证书同步

 - 1> mv /opt/dss/MTS/cacert.pem /opt/dss/MTS/cacert_backup.pem 
  
 - 2> mv /opt/dss/MTS/privkey.pem /opt/dss/MTS/privkey_backup.pem 
  
 - 3> cp /opt/3rdtool/nginx/ssl/service.pem  /opt/dss/MTS/cacert.pem
  
 - 4> cp /opt/3rdtool/nginx/ssl/service_unsercure.key  /opt/dss/MTS/privkey.pem
  
 - 5> pidof MTS
  
 - 6> kill -9 第5步进程号


- 录像回放证书同步

 - 1> mv /opt/dss/SS/cacert.pem /opt/dss/SS/cacert_backup.pem 
  
 - 2> mv /opt/dss/SS/privkey.pem /opt/dss/SS/privkey_backup.pem 
  
 - 3> cp /opt/3rdtool/nginx/ssl/service.pem  /opt/dss/SS/cacert.pem
  
 - 4> cp /opt/3rdtool/nginx/ssl/service_unsercure.key  /opt/dss/SS/privkey.pem
  
 - 5> pidof SS
  
 - 6> kill -9 第5步进程号