[入口说明](#index)
[PlayerManager 功能API介绍](#intro)

# 入口说明


# 1、PlayerManager 功能API介绍
<span id="intro"></span>

表格表示的是每个功能API的方法介绍
表格下面会有每种方法的详细使用说明和代码示例

| 方法名 | 参数 | 描述 |
| --- | --- | --- |
| [constructor](#constructor) | options | 初始化播放器 |
| [initRealPlayer](#initRealPlayer) | options | 用来初始化实时预览播放器 |
| [initRecordPlayer](#initRecordPlayer) | options | 用来初始化录像回放播放器 |
| [playRealVideo](#playRealVideo) | options | 用于实时预览播放 |
| [playRecordVideo](#playRecordVideo) | options | 用于录像回放播放 |
| [realByUrl](#realbyurl) | options | 流地址方式预览 |
| [recordByUrl](#recordByUrl) | options | 流地址方式录像回放 |
| [pause](#pause) | 无 | 选中的视频窗口暂停录像回放播放，只有录像回放且视频在播放调用才有效 |
| [play](#play) | 无 | 选中的视频窗口继续录像回放播放，只有录像回放且视频暂停中调用才有效 |
| [playSpeed](#playSpeed) | speed | 选中的视频窗口根据指定的速率播放，只有录像回放且视频播放中调用才有效 |
| [openVolume](#openVolume) | options | 开启声音 |
| [closeVolume](#closeVolume) | options | 关闭声音 |
| [setVolume](#setVolume) | options | 设置音量 |
| [startLocalRecord](#startLocalRecord) | options | 开始录像下载 |
| [stopLocalRecord](#stopLocalRecord) | options | 停止录像下载 |
| [setIvs](#setIvs) | options | 设置规则线 |
| [picCap](#picCap) | options | 抓图 |
| [setFullScreen](#setFullScreen) | 无 | 设置全屏 |
| [setPlayerAdapter](#setPlayerAdapter) | playerAdapter | 设置窗口自适应还是拉伸显示 |
| [setPlayerNum](#setPlayerNum) | number | 设置播放器显示的路数 |
| [setSelectIndex](#setSelectIndex) | index | 设置选中的播放器窗口 |
| [jumpPlayByTime](#jumpPlayByTime) | time | 录像跳转播放 |
| [close](#close) | index | 关闭正在播放的视频窗口，并释放内存 |

# constructor
<span id="constructor"></span>

### 定义和用法
constructor PlayerManager构造器

|语法|示例|
|---|---|
|JavaScript 语法| let player = new PlayerManager(options) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| type | string（"real"/"record"） | 必须，用于创建实时预览还是录像回放播放器 |
| maxNum | number | 必须，用于最大可以创建多少个窗口，默认4窗口，最大16个 |
| num | number | 必须，初始化显示第几个窗口，默认第一个 |
| showControl | boolean | 必须，是否显示控制栏，默认显示 |
| receiveMessageFromWSPlayer | Function | 一个函数，监听wsplayer的所有事件回调，详细查阅 --> 事件回调说明 <--

### 代码示例
```js
let player = new PlayerManager({
    type: "real",
    maxNum: 4,
    num: 1,
    showControl: true,
    serverIp: "124.160.33.135", // 代理IP
    config: { // wsplayer 相关配置信息，详细请看 --> 配置参数说明 <--
        ...
    },
    receiveMessageFromWSPlayer: __receiveMessageFromWSPlayer // 该函数位监听回调
});
```


<span id="playRealVideo"></span>

# playRealVideo


### 定义和用法
playRealVideo 实时预览播放方法

|语法|示例|
|---|---|
|JavaScript 语法| player.playRealVideo(options) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| options.channelList | ArrayList | 必须，播放的通道对象列表 |
| options.streamType | string/number | 可选，使用哪种码流播放，默认辅码流1。若没有辅码流1则自动切换主码流。 |
| options.windowIndex | number | 可选，在第几个窗口播放。多个通道同时播放，则从第一个窗口播放，否则从选中的窗口播放 |

### 代码示例
```js
player.playRealVideo({
    channelList: [{
        id: "100001$1$0$1", // 通道id
        isOnline: 1 // 是否在线 1-在线 (树接口会返回) 0-离线
    }], // 可传入多个通道id, 数组表示。
    streamType: 1,
    windowIndex: 0, // 窗口序列从0开始，如果有多个通道播放，则从此窗口开始依次往后进行播放。
})
```

<span id="playRecordVideo"></span>

# playRecordVideo

### 定义和用法
playRecordVideo 录像回放播放方法

|语法|示例|
|---|---|
|JavaScript 语法| player.playRecordVideo(options) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| options.channelList | Array | 必须，播放的通道对象列表 |
| options.startTime | string/number | 必须，开始时间，timestamp到秒 |
| options.endTime | string/number | 必须，开始时间，timestamp到秒 |
| options.recordSource | string/number | 必须，录像来源，2表示设备录像  3表示中心录像 |
| options.streamType | string/number | 可选，码流类型 |
| options.recordType | string/number | 可选，录像类型 |

### 代码示例
```js
player.playRecordVideo({
    channelList: ["100001$1$0$1"], // 可传入多个通道id, 数组表示。
    startTime: new Date().getTime() / 1000,  // 传入的时间为秒  (注意一定一定不要传毫秒，否则无法播放);
    endTime: new Date().getTime() / 1000,  // 传入的时间为秒  (注意一定一定不要传毫秒，否则无法播放);
    recordSource: 2,
    streamType: 1,
    recordType: 0,
    windowIndex: 0, // 窗口序列从0开始，如果有多个通道播放，则从此窗口开始依次往后进行播放。
})
```

<span id="realByUrl"></span>

# realByUrl

### 定义和用法

realByUrl 通过ws和rtsp方式流地址播放实时预览。

|语法|示例|
|---|---|
|JavaScript 语法| player.realByUrl(options) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| options.wsURL | string | 必须，播放建立的websocket地址 |
| options.rtspURL | string |  必须，rtsp地址 |
| options.xxx | any | 可选，传入什么，在realSuccess内就会返回什么 |

### 代码示例
```js
player.realByUrl({
    wsURL: 'ws://135.120.12.15:9100/', // 建立的websocket连接
    rtspURL: 'rtsp://135.120.12.15:9100/dss/monitor/param/cameraid=1000007%240%26substream=2?token=30', // 接口返回的rtsp地址
})
```

<span id="recordByUrl"></span>

# recordByUrl

### 定义和用法

recordByUrl 通过ws和rtsp方式流地址播放实时预览。

|语法|示例|
|---|---|
|JavaScript 语法| player.recordByUrl(options) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| options.wsURL | string | 必须，播放建立的websocket地址 |
| options.rtspURL | string |  必须，rtsp地址 |
| options.records | array | 选：如果要展示进度条则必须传 |
| options.xxx | any | 可选，传入什么，在recordSuccess内就会返回什么 |

### 代码示例
```js
player.recordByUrl({
    wsURL: 'ws://135.120.12.15:9100/', // 建立的websocket连接
    rtspURL: 'rtsp://135.120.12.15:9100/ss/playback?token=30', // 接口返回的rtsp地址
})
```


<span id="setPlayerAdapter"></span>

# setPlayerAdapter

### 定义和用法
setPlayerAdapter 设置窗口自适应还是拉伸显示

|语法|示例|
|---|---|
|JavaScript 语法| player.setPlayerAdapter(playerAdapter) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| playerAdapter | string | 必须，设置窗口自适应还是拉伸显示，selfAdaption-自适应 stretching-拉伸 |

### 代码示例
```js
player.setPlayerAdapter("selfAdaption"); // 自适应
player.setPlayerAdapter("stretching"); // 拉伸
```

<span id="playSpeed"></span>

# playSpeed

### 定义和用法
playSpeed 设置录像回放播放的速率 （实时预览不支持倍速， 录像回放才支持）

|语法|示例|
|---|---|
|JavaScript 语法| player.playSpeed(speed) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| speed | number | 必须，速率 0.125 0.25 0.5 1 1.25 1.5 2 4 8 共 9 种速率 |

### 代码示例
```js
player.playSpeed(1)
```

<span id="openVolume"></span

# openVolume

### 定义和用法
openVolume 开启声音

|语法|示例|
|---|---|
|JavaScript 语法| player.openVolume(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |

### 代码示例
```js
player.openVolume(0); // 第1个窗口开启声音
```

<span id="closeVolume"></span>

# closeVolume

### 定义和用法
closeVolume 开启声音

|语法|示例|
|---|---|
|JavaScript 语法| player.closeVolume(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |

### 代码示例
```js
player.closeVolume(0); // 第1个窗口开启声音
```

<span id="setVolume"></span>

# setVolume

### 定义和用法
setVolume 开启声音

|语法|示例|
|---|---|
|JavaScript 语法| player.setVolume(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |
| volume | float | 0-1之间，一位小数的浮点数如： 0.1 0.2 ... 0.9 |

### 代码示例
```js
player.setVolume(0, 0.5); // 第1个窗口设置声音为 50%
```

<span id="startLocalRecord"></span>

# startLocalRecord

### 定义和用法
startLocalRecord 开始录制视频

|语法|示例|
|---|---|
|JavaScript 语法| player.startLocalRecord(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |

### 代码示例
```js
player.startLocalRecord(0); // 第1个窗口开始进行视频录制
```

<span id="stopLocalRecord"></span>

# stopLocalRecord

### 定义和用法
stopLocalRecord 停止录制视频

|语法|示例|
|---|---|
|JavaScript 语法| player.stopLocalRecord(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |

### 代码示例
```js
player.stopLocalRecord(0); // 第1个窗口停止视频录制
```

<span id="setIvs"></span>

# setIvs

### 定义和用法
setIvs 智能帧设置

|语法|示例|
|---|---|
|JavaScript 语法| player.setIvs(showIvs, windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| showIvs | boolean | 智能帧开关，全局配置 |
| windowIndex | number | 窗口序号(从0开始) |

### 代码示例
```js
player.setIvs(true, 0); // true-开启智能帧  false-关闭智能帧
```

<span id="picCap"></span>

# picCap

### 定义和用法
picCap 抓图

|语法|示例|
|---|---|
|JavaScript 语法| player.picCap(windowIndex) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| windowIndex | number | 必须，窗口序号 |

### 代码示例
```js
player.picCap(0); // 抓图
```


<span id="setPlayerNum"></span>

# setPlayerNum

### 定义和用法
setPlayerNum 设置播放器显示的路数

|语法|示例|
|---|---|
|JavaScript 语法| player.setPlayerNum(number) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| number | number | 必须，可选数值：1 4 9 16 25 共5种路数显示。但是不会超过创建播放器的maxNum（new PlayerManager设置的maxNum） |

### 代码示例
```js
player.setPlayerNum(1) // 设置播放窗口
```


<span id="setSelectIndex"></span>

# setSelectIndex

### 定义和用法
setSelectIndex 设置需要选中的播放器的窗口索引

|语法|示例|
|---|---|
|JavaScript 语法| player.setSelectIndex(index) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| index | number | 必须，需要选中的播放器的窗口索引, 从 0 开始 |

### 代码示例
```js
player.setSelectIndex(0) // 设置播放窗口
```


<span id="jumpPlayByTime"></span>

# jumpPlayByTime

### 定义和用法
jumpPlayByTime 录像跳转播放

|语法|示例|
|---|---|
|JavaScript 语法| player.jumpPlayByTime(time) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| time | string | 必须，录像跳转播放的时间，HH:mm:ss 格式|

### 代码示例
```js
player.jumpPlayByTime("05:59:59") // 设置录像需要跳转到的录像时间。
```

<span id="close"></span>

# close

### 定义和用法
close 关闭正在播放的视频窗口

|语法|示例|
|---|---|
|JavaScript 语法| player.close(index) |

### 参数
| 参数 | 类型 | 描述|
| --- | --- | --- |
| index | number | 可选。关闭指定索引的窗口的视频。若不填则关闭所有视频。 索引从 0 开始 |

### 代码示例
```js
player.close(0) // 索引从 0 开始
```
