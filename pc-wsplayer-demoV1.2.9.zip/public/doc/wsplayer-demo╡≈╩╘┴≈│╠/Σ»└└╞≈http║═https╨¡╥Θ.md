## 切换 http/https 协议
wsplayer 启动默认是 https 协议，使用 wss 连接拉流。

如果需要通过http协议，使用 ws 直连拉流。需要更改 `vite.config.js` 中的代码，并重启服务。
```js
// ...
export default defineConfig({
	// ...
	plugins: [
		// ...
		// basicSsl() // 注释该行
	],
	server: {
		// https: true,  // 注释该行
		// ...
	}
})
```