/*
 * @Author: 110285 liu_cancan@dahuatech.com
 * @Date: 2022-09-19 15:03:32
 * @LastEditors: 110285 liu_cancan@dahuatech.com
 * @LastEditTime: 2022-09-19 16:26:00
 * @FilePath: \koa-proxy-master\server.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
/*eslint-disable*/
const Koa = require('koa')
const bodyParser = require('koa-bodyparser')
const {createProxyMiddleware} = require('http-proxy-middleware')
const k2c = require('koa2-connect')
const path = require('path')
const koaStatic = require('koa-static')
const config = require('./config')

const app = new Koa()

app
    .use(async (ctx, next) => {
        console.log(`Process ${JSON.stringify(ctx.request.header)}`)
        let proxyIP = `https://${ctx.request.header.proxyip}/`
        for(let i = 0; i < config.services.length; i++) {
            let service = config.services[i]
            let assertions = Object.keys(service.assertions)
            let ifValidate = true
            for(let j = 0; j < assertions.length; j++) {
                let method = assertions[j]
                let str = service.assertions[method]
                if(!ctx.url[method](str)) ifValidate = false
            }
            if(ifValidate) {
                ctx.respond = false

                await k2c(
                    createProxyMiddleware({
                        target: proxyIP,
                        changeOrigin: true,
                        secure: false,
                        pathRewrite: service.rewrite || {}
                    })
                )(ctx, next)
                break
            }
        }
        ctx.response.set("Cross-Origin-Embedder-Policy", "credentialless")
        ctx.response.set("Cross-Origin-Opener-Policy", "same-origin")
        ctx.response.set("Cross-Origin-Resource-Policy", "cross-origin")
        await next()
    })
    .use(
        bodyParser({
            enableTypes: ['json', 'form', 'text']
        })
    )
    .use(koaStatic(path.join(__dirname, 'html')))

app.listen(config.port, '0.0.0.0')

console.info('Server running in Port ' + config.port)
