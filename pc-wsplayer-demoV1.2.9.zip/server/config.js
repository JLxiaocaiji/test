module.exports = {
  port: 9999,
  services: [
    {
      // 代理服务的名字，起备注作用
      name: 'ICC服务代理',
      // url字符串条件断言，url满足以下断言才能进入本代理,注意各个条件之间是 "与" 关系
      // 支持的断言条件：includes endsWith startsWith,即ES6提供的字符串方法，区分大小写
      assertions: { includes: '/evo-apigw' },
      // 需要代理到的目标URL，注意结尾的斜杠
      target: 'https://10.55.36.150/',
      // 如果需要重写路径的话就在这里添加，键名支持正则表达式
      rewrite: { '^/': '/' }
    }
  ]
}
