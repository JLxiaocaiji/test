<template>
    <div class="doc-content">
        <div class="md-body" v-html="content"></div>
    </div>
</template>

<script>
import mixins from "./mixin/mixin";

export default {
    name: 'test',
    mixins: [mixins],
    data() {
        return {
            selectedKeys: ["0"],
            content: "",
        }
    },
    methods: {
        renderMd() {
            this.getMd("/doc/快速开始.md")
        },
        handleMenuClick(e) {
            this.selectedKeys = [e.key];
            this.renderMd(e.key);
        }
    },
    mounted() {
        this.renderMd();
    }
}
</script>

<style lang="less">
@import "./md.less";

.doc-content{
    display: flex;
    height: 100%;
    overflow: auto;

    .md-body{
        height: calc(100% - 40px);
        overflow: auto;
        margin: 20px;
        padding: 20px;
        background: #FFF;
        flex: 1;
    }
}
</style>
