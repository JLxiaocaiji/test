<template>
    <div class="doc-content">
        <a-menu
            v-model:openKeys="openKeys"
            v-model:selectedKeys="selectedKeys"
            style="width: 256px"
            mode="inline"
            @click="handleMenuClick"
        >
            <template v-for="menuItem in docMenu" :key="menuItem.key">
                <a-sub-menu v-if="menuItem.children" :title="menuItem.title" :key="menuItem.key">
                    <a-menu-item v-for="menuItemChild in menuItem.children" :key="menuItemChild.key">{{menuItemChild.title}}</a-menu-item>
                </a-sub-menu>

                <a-menu-item v-else :key="menuItem.key">{{menuItem.title}}</a-menu-item>
            </template>
        </a-menu>

        <div class="md-body" v-html="content"></div>
    </div>
</template>

<script>
import mixins from "./mixin/mixin";

export default {
    name: 'test',
    mixins: [mixins],
    data() {
        return {
            selectedKeys: ["0-0"],
            openKeys: ["0", "2"],
            content: "",
        }
    },
    methods: {
        renderMd(keys) {
            // 拼接md地址
            let mdUrl = "/doc";
            let keyList = keys.split("-");
            if(keyList.length > 1) {
                let menuItem = this.docMenu[keyList[0]];
                let menuChildItem = menuItem.children[keyList[1]]
                mdUrl = `${mdUrl}/${menuItem.title}/${menuChildItem.title}.md`;
            } else {
                mdUrl = `${mdUrl}/${this.docMenu[keyList[0]].title}.md`
            }
            this.getMd(mdUrl);
        },
        handleMenuClick(e) {
            this.selectedKeys = [e.key];
            this.renderMd(e.key);
        }
    },
    mounted() {
        this.renderMd("0-0");
    },
    computed: {
        docMenu() {
            return [
                {
                    title: "wsplayer-demo调试流程",
                    key: "0",
                    children: [
                        {title: "调试流程", key: "0-0"},
                        {title: "打包部署", key: "0-1"},
                        {title: "浏览器http和https协议", key: "0-2"},
                    ]
                },
                {title: '三方后端接口对接', key: '1'},
                {title: '证书配置', key: '2'}
                // {
                //     title: "ICC子系统开发对接流程",
                //     key: "1",
                //     children: [
                //         {title: "1.nginx配置", key: "1-0"},
                //         {title: "2.子系统集成", key: "1-1"},
                //         {title: "3.云台功能", key: "1-2"},
                //         {title: "问题排查", key: "1-3"},
                //     ]
                // },
                // {
                //     title: "前端对接模式",
                //     key: "2",
                //     children: [
                //         {title: '对接模式说明', key: "2-0"},
                //         {title: 'http下ws直连拉流', key: '2-1'},
                //         {title: 'https下wss直连拉流', key: '2-2'},
                //         {title: "wss代理映射", key: "2-3"},
                //         {title: "ws代理映射", key: "2-4"},
                //     ]
                // },
                // {title: "内外网环境说明", key: "3"},
            ];
        }
    }
}
</script>

<style lang="less">
@import "./md.less";

.doc-content{
    display: flex;
    width: 1400px;
    height: 100%;
    margin: 20px auto;
    overflow: auto;

    .md-body{
        height: calc(100% - 40px);
        overflow: auto;
        margin: 20px;
        padding: 20px;
        background: #FFF;
        flex: 1;
    }
}
</style>
