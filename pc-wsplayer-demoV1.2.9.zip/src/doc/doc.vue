<template>
    <div class="doc-content">
        <a-menu
            v-model:selectedKeys="selectedKeys"
            style="width: 256px"
            mode="inline"
            @click="handleMenuClick"
        >
            <template v-for="menuItem in docMenu" :key="menuItem.key">
                <a-sub-menu v-if="menuItem.children" :title="menuItem.title" :key="menuItem.key">
                    <a-menu-item v-for="menuItemChild in menuItem.children" :key="menuItemChild.key">{{menuItemChild.title}}</a-menu-item>
                </a-sub-menu>

                <a-menu-item v-else :key="menuItem.key">{{menuItem.title}}</a-menu-item>
            </template>
        </a-menu>

        <div class="md-body" v-html="content"></div>
    </div>
</template>

<script>
import mixins from "./mixin/mixin";

export default {
    name: 'test',
    mixins: [mixins],
    data() {
        return {
            selectedKeys: ["0"],
            content: "",
        }
    },
    methods: {
        renderMd(keys) {
            // 拼接md地址
            let mdUrl = "/doc";
            let keyList = keys.split("-");
            if(keyList.length > 1) {
                let menuItem = this.docMenu[keyList[0]];
                let menuChildItem = menuItem.children[keyList[1]]
                mdUrl = `${mdUrl}/${menuItem.title}/${menuChildItem.title}.md`;
            } else {
                mdUrl = `${mdUrl}/${this.docMenu[keyList[0]].title}.md`
            }
            this.getMd(mdUrl);
        },
        handleMenuClick(e) {
            this.selectedKeys = [e.key];
            this.renderMd(e.key);
        }
    },
    mounted() {
        this.renderMd("0");
    },
    computed: {
        docMenu() {
            return [
                {title: "简介", key: "0"},
                {title: "FAQ", key: "1"},
                {
                    title: "wsplayer介绍",
                    key: "2",
                    children: [
                        {title: "api介绍", key: "2-0"},
                        {title: "事件介绍", key: "2-1"},
                        {title: "配置介绍", key: "2-2"},
                        {title: "提示错误信息", key: "2-3"},
                        {title: "最佳实践", key: "2-4"},
                    ]
                },
                {
                    title: "wsplayer调试流程",
                    key: "3",
                    children: [
                        {title: "调试流程", key: "3-0"},
                    ]
                },
                {
                    title: "子系统开发流程",
                    key: "4",
                    children: [
                        {title: "1.nginx配置", key: "4-0"},
                        {title: "2.子系统集成", key: "4-1"},
                        {title: "3.云台功能", key: "4-2"},
                        {title: "问题排查", key: "4-3"},
                    ]
                },
                {
                    title: "第三方开发对接流程",
                    key: "5",
                    children: [
                        {title: "1.nginx配置", key: "5-0"},
                        {title: "2.项目集成", key: "5-1"},
                        {title: "3.云台功能", key: "5-2"},
                    ]
                },
            ];
        }
    }
}
</script>

<style lang="less">
@import "./md.less";

.doc-content{
    display: flex;
    width: 1400px;
    height: 100%;
    margin: 20px auto;
    overflow: auto;

    .md-body{
        height: calc(100% - 40px);
        overflow: auto;
        margin: 20px;
        padding: 20px;
        background: #FFF;
        flex: 1;
    }
}
</style>
