import {marked} from "marked"
var hljs = await import('highlight.js/lib/core')

import 'highlight.js/styles/github.css'
import javascript from 'highlight.js/lib/languages/javascript'
import markdown from 'highlight.js/lib/languages/markdown'
import xml from 'highlight.js/lib/languages/xml'

hljs.default.registerLanguage('xml', xml);
hljs.default.registerLanguage('javascript', javascript)
hljs.default.registerLanguage('markdown', markdown)


marked.setOptions({
    renderer: new marked.Renderer(),
    highlight: function(code, lang) {
        return hljs.default.highlightAuto(code).value;
    },
    // langPrefix: "hljs language-",
    // pedantic: false,
    gfm: true,
    tables: true,
    breaks: false,
    sanitize: false,
    smartLists: true,
    smartypants: false,
    xhtml: false,
})

var renderer = new marked.Renderer();

renderer.table = function (header, body) {
    return '<table class="table table-striped">'+header+body+'</table>'
}

export default {
    methods: {
        getMd(mdUrl) {
            if(process.env.NODE_ENV !== "development") {
                mdUrl = `/wsplayer${mdUrl}`;
            }
            this.$http.get(mdUrl).then(res => {
                this.content = marked(res.data, {renderer});
            })
        }
    }
}
