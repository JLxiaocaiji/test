<template>
    <div class="doc-content">
        <a-menu
            v-model:selectedKeys="selectedKeys"
            style="width: 256px"
            mode="inline"
            @click="handleMenuClick"
        >
            <template v-for="menuItem in docMenu" :key="menuItem.key">
                <a-sub-menu v-if="menuItem.children" :title="menuItem.title" :key="menuItem.key">
                    <a-menu-item v-for="menuItemChild in menuItem.children" :key="menuItemChild.key">{{menuItemChild.title}}</a-menu-item>
                </a-sub-menu>

                <a-menu-item v-else :key="menuItem.key">{{menuItem.title}}</a-menu-item>
            </template>
        </a-menu>

        <div class="md-body" v-html="content"></div>
    </div>
</template>

<script>
import mixins from "./mixin/mixin";

export default {
    name: 'test',
    mixins: [mixins],
    data() {
        return {
            selectedKeys: ["0"],
            content: "",
        }
    },
    methods: {
        renderMd(keys) {
            // 拼接md地址
            let mdUrl = "/doc";
            let keyList = keys.split("-");
            if(keyList.length > 1) {
                let menuItem = this.docMenu[keyList[0]];
                let menuChildItem = menuItem.children[keyList[1]]
                mdUrl = `${mdUrl}/${menuItem.title}/${menuChildItem.title}.md`;
            } else {
                mdUrl = `${mdUrl}/${this.docMenu[keyList[0]].title}.md`
            }
            this.getMd(mdUrl);
        },
        handleMenuClick(e) {
            this.selectedKeys = [e.key];
            this.renderMd(e.key);
        }
    },
    mounted() {
        this.renderMd("0");
    },
    computed: {
        docMenu() {
            return [
                {title: "FAQ", key: "0"},
                {title: "常见问题记录", key: "1"},
                {title: "无插件播放器在钉钉页面的使用", key: "2"},
                {title: "控制台报错记录", key: "3"}
            ];
        }
    }
}
</script>

<style lang="less">
@import "./md.less";

.doc-content{
    display: flex;
    width: 1400px;
    height: 100%;
    margin: 20px auto;
    overflow: auto;

    .md-body{
        height: calc(100% - 40px);
        overflow: auto;
        margin: 20px;
        padding: 20px;
        background: #FFF;
        flex: 1;
    }
}
</style>
