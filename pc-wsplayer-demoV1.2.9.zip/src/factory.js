import { request } from './common/request.js'
import JSEncrypt from "jsencrypt"
// const vueApp = window.vm.config.globalProperties
function getPublickKey(ip) {
    return new Promise((resolve, reject) => {
        request({
            method: "get",
            url: `evo-oauth/1.0.0/oauth/public-key?t=${new Date().getTime()}`,
        }).then(res => {
            resolve(res)
        })
    })
}
function getCurrentRtsp(url) {
    let urls = url.split('|')
    let curUrl
    curUrl = urls.find(item => { return item.includes(window.location.hostname) }) || urls[0]
    return curUrl;
}

function getStartTime() {
    return parseInt(new Date(new Date(new Date().toLocaleDateString()).getTime()) / 1000)
}
function getEndTime() {
    return parseInt(new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1) / 1000)
}
/**
 * @augments
 * @method encryption()  加密
 * @param
 * publicKey:公钥；password:密码
 */
function encryption(publicKey, password) {
    let encryptor = new JSEncrypt();
    encryptor.setPublicKey(publicKey);
    let psw = encryptor.encrypt(password);
    return psw;
}
export default {
    // 登录服务器
    loginServer(param) {
        return new Promise((resolve, reject) => {
            getPublickKey().then(res => {
                let publicKey = res.publicKey
                let value = {
                    'username': param.username,
                    'password': encryption(publicKey, param.password),
                    'code': "",
                    'grant_type': 'password',
                    'client_id': 'web_client',
                    "client_secret": 'web_client',
                    "public_key": publicKey,
                    "verifyCodeFlag": 1
                }
                request({
                    method: 'post',
                    contentType: 'application/x-www-form-urlencoded',
                    url: `evo-oauth/oauth/token`,
                    data: value
                }).then(res => {
                    resolve(res)
                }).catch(err => {
                    reject(err)
                })
            })
        })
    },
     /**
     * @method fetchRealRTSP 获取实时视频RTSP地址
     */
    fetchRealRTSP(params) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: 'admin/API/MTS/Video/StartVideo',
                data: params
            }).then((res) => {
                resolve(res)
            }).catch(err => {
                reject(err)
            })
        })
    },
    /**
     * getDeviceData获取设备树
     */
    getDeviceData(param) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `evo-brm/1.2.0/tree`,
                data: param,
                isSNoTip: true
            }).then(res => {
                resolve(res)
            }).catch(err => {
                reject(err)
            })
        })
    },
    // 获取rtsp
    getCurrentRtsp(url) {
        let urls = url.split('|')
        let curUrl
        curUrl = urls.find(item => { return item.includes(window.location.hostname) }) || urls[0]
        return curUrl;
    },
     /**
     * 云台方向控制
     * @param directionParam
     * @returns {Promise<unknown>}
     */
      setPtzDirection(directionParam) {
        return new Promise((resolve,reject) => {
            request({
                url: '/admin/API/DMS/Ptz/OperateDirect',
                data: directionParam,
                method: "post",
            }).then(res => {
                resolve(res.data)
            }).catch(res => {
                reject(res.errMsg)
            })
        })
    },
    /**
     * 云台镜头控制
     * @param cameraParam
     * @returns {Promise<unknown>}
     */
    setPtzCamera(cameraParam) {
        return new Promise((resolve,reject) => {
            request({
                url: '/admin/API/DMS/Ptz/OperateCamera',
                data: cameraParam,
                method: "post",
            }).then(res => {
                resolve(res.data)
            }).catch(res => {
                reject(res.errMsg)
            })
        })
    },
    /**
     * @method fetchRealRTSP 获取IPC对讲RTSP地址
     */
    fetchTalkRTSP(params) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `admin/API/MTS/Audio/StartTalk`,
                isSNoTip: true,
                isENoTip: true,
                data: params
            }).then(res => {
                resolve(res.data.data)
            }).catch(res => {
                reject(res)
            })
        })
    },
    /**
     * 获取实时视频RTSP地址
     */
    getRecordRtspByTime(params) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `admin/API/SS/Playback/StartPlaybackByTime`,
                isSNoTip: true,
                isENoTip: false,
                data: params
            }).then(res => {
                resolve(res.data.data)
            }).catch(res => {
                reject(res)
            })
        })
    },
    /**
     * 查询中心录像上的录像文件信息
     */
    queryRecords(params) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `admin/API/SS/Record/QueryRecords`,
                isSNoTip: true,
                isENoTip: false,
                data: params
            }).then(res => {
                resolve(res.data.data)
            }).catch(res => {
                reject(res)
            })
        })
    },
    /**
     * 根据文件形式回放录像
     */
    startPlaybackByFile(params) {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `admin/API/SS/Playback/StartPlaybackByFile`,
                isSNoTip: true,
                isENoTip: false,
                data: params
            }).then(res => {
                resolve(res.data.data)
            }).catch(res => {
                reject(res)
            })
        })
    },
    // 保活
    keepalive() {
        return new Promise((resolve, reject) => {
            request({
                method: 'post',
                url: `evo-brm/1.2.0/user/keepalive`,
                isSNoTip: true,
                isENoTip: false,
                data: {
                    clientType: 1,
                    magicId: localStorage.magicId,
                    timeout: 10000
                }
            }).then(res => {
                resolve(res.data.data)
            }).catch(res => {
                reject(res)
            })
        })
    }
}
