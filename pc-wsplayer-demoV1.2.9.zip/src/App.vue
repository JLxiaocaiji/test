<template>
    <a-config-provider :locale="zhCN">
    <div class="wsplayer-demo-main-wrapper">
        <a-layout class="wsplayer-demo-wrapper">
            <!-- 导航栏 -->
            <a-layout-header>
                <div class="wsplayer-demo-wrapper-header">
                    <div class="logo">
                        <span>WSPlayer-大华播放器</span>
                        <a-menu
                            theme="dark"
                            mode="horizontal"
                            :selectedKeys="selectedTabs.value"
                            :style="{ lineHeight: '64px', marginLeft:'16px' }"
                        >
                            <a-menu-item v-for="item in tabList" :key="item.id" @click="changeMenu(item)">
                                {{ item.name }}
                            </a-menu-item>
                        </a-menu>
                    </div>
                    <!-- 登录 -->
                    <div v-if="showLogin">
                        <span class="login" @click="toLogin" v-if="!loginStatus">登录</span>
                        <span class="login" v-if="loginStatus">{{ ip }}</span>
                        <span class="login" @click="toLogin" v-if="loginStatus">重新登录</span>
                    </div>
                </div>
            </a-layout-header>
            <div v-show="selectedTabs ==='1'" class="operation-content">
                <!-- 左侧操作栏 -->
                <div class="operation-content-left">
                    <left-operate v-if="showOperate" :mode="activeKey" @searchRecord="searchRecord"></left-operate>
                    <div id="ws-pan-tilt" v-show="activeKey !== 'record'"></div>
                </div>
                <!-- 视频播放操作 -->
                <div class="right-video-wrapper">
                    <a-tabs v-model:activeKey="activeKey" class="right-video-tabs">
                        <a-tab-pane key="real" tab="实时预览">
                            <wsplayer ref="realPlayer" type="real"></wsplayer>
                        </a-tab-pane>
                        <a-tab-pane key="record" tab="录像回放">
                            <wsplayer ref="recordPlayer" type="record"></wsplayer>
                        </a-tab-pane>
                    </a-tabs>
                </div>
            </div>

            <Start v-show="selectedTabs ==='2'"/>
            <Demo v-show="selectedTabs === '3'"/>
            <Api v-show="selectedTabs ==='4'"/>
            <Notice v-show="selectedTabs === '5'"/>
            <ChangeLog v-show="selectedTabs === '6'"></ChangeLog>
        </a-layout>
        <!-- 登录弹窗 -->
        <a-modal
            title="登录服务器"
            :visible="visible"
            closable
            :keyboard="false"
            :maskClosable="false"
            @cancel="cancel"
        >
            <a-form class="loginForm" :model="formState" name="basic" autocomplete="off"
                    :label-col="{ span: 8 }"
                    :wrapper-col="{ span: 16 }">
                <a-form-item label="ICC地址" name="proxyIp" v-show="showLoginIp">
                    <a-input v-model:value="formState.proxyIp" placeholder="请输入ICC地址"/>
                </a-form-item>
                <a-form-item label="用户名" name="username">
                    <a-input v-model:value="formState.username" placeholder="请输入用户名"/>
                </a-form-item>
                <a-form-item label="密码" name="password">
                    <a-input-password v-model:value="formState.password" placeholder="请输入密码"/>
                </a-form-item>
            </a-form>
            <template #footer>
                <a-button @click="cancel">取消</a-button>
                <a-button type="primary" @click="login">登录</a-button>
            </template>
        </a-modal>
    </div>
    </a-config-provider>
</template>

<script>
import leftOperate from './components/leftOperate.vue'
import wsplayer from './components/WSPlayerComponent.vue'
import api from './factory';
import {videoStore} from "./store/index";
import zhCN from 'ant-design-vue/es/locale/zh_CN';
import 'dayjs/locale/zh-cn';
import doc from "./doc/doc.vue";
import Start from "./doc/Start.vue";
import Demo from "./doc/Demo.vue";
import Api from "./doc/Api.vue";
import Notice from "./doc/Notice.vue";
import ChangeLog from "./doc/ChangeLog.vue";
import serverConfig from "../config/config";

export default {
    data() {
        let devEnv = process.env.NODE_ENV === "development";
        let showLogin = devEnv || import.meta.env.VITE_NODE_ENV === 'wiki';
        return {
            zhCN,
            tabList: [
                {
                    id: "1",
                    name: '首页'
                },
                {
                    id: "2",
                    name: '快速入门'
                },
                {
                    id: '3',
                    name: "调试配置"
                },
                {
                    id: '4',
                    name: '功能API'
                },
                {
                    id: "5",
                    name: '问题答疑'
                },
                {
                    id: "6",
                    name: '版本迭代'
                }
            ],
            selectedTabs: "1",
            videoTypeList: [ //切换实时预览、录像回放tabList
                {
                    mode: "real",
                    tabText: "实时预览",
                },
                {
                    mode: "record",
                    tabText: "录像回放",
                }
            ],
            activeKey: "real",
            formState: {   //登录 info
                username: "",
                password: "",
                proxyIp: "",
            },
            ip: localStorage['proxyIp'],
            showLogin,
            // 本地调试无需输入IP
            showLoginIp: !devEnv,
            // 登录框显隐（wiki模式下，才需要登录）
            visible: showLogin && !localStorage['proxyIp'],
            // showLoginCancel: !!localStorage['proxyIp'], // 登录框是否显示取消按钮
            loginStatus: !!localStorage['proxyIp'],  //登录状态
            showOperate: true,  //操作栏显隐
        }
    },
    components: {
        leftOperate,
        wsplayer,
        doc,
        Start,
        Demo,
        Api,
        Notice,
        ChangeLog
    },
    methods: {
        // 登录
        toLogin() {
            this.visible = true
        },
        // 登录失败监听
        loginout() {
            this.$emit('loginout')
        },
        onKeyDown(e) {
            if(e.key === 'Enter' || e.keyCode === 13) {
                if(this.visible) {
                    this.login()
                }
            }
        },
        login() {
            videoStore() && videoStore().setLogin(false);
            localStorage.setItem("proxyIp", this.formState.proxyIp || serverConfig.ip)
            const login = (isTip) => {
                api.loginServer(this.formState).then(res => {
                    isTip && this.$message.success("登录成功")
                    videoStore() && videoStore().setLogin(true);
                    this.ip = this.formState.proxyIp;
                    localStorage.setItem("UserName", this.formState.username);
                    localStorage.setItem("accessToken", res.access_token);
                    localStorage.setItem("refreshToken", res.refresh_token);
                    localStorage.setItem("userId", res.userId);
                    localStorage.setItem("magicId", res.magicId);
                    localStorage.setItem("remainderDays", res.remainderDays || "");
                    this.visible = false;
                    this.loginStatus = true;
                    // this.showLoginCancel = true;
                    // 初始化播放器
                    let playerStr = this.activeKey === "real" ? "realPlayer" : "recordPlayer";
                    this.$refs[playerStr].initPlayer();
                }).catch(err => {
                    this.$message.error("登录失败，请检查用户名和密码")
                })
            }
            login(true)
            clearInterval(this.interval)
            this.interval = setInterval(() => {
                login()
            }, 5 * 60 * 1000)
        },
        //切换视频播放tab
        changeMenu(item) {
            this.selectedTabs = item.id;
            this.activeKey = "real";
        },
        cancel() {
            this.visible = false
        },
        //查询record信息
        searchRecord(value) {
            this.$refs["recordPlayer"].receive({
                method: "playRecordVideo",
                data: value
            });
        }
    },
    mounted() {
        // 初始化播放器
        let playerStr = this.activeKey === "real" ? "realPlayer" : "recordPlayer";
        this.$refs[playerStr].initPlayer();
        document.addEventListener("keydown", this.onKeyDown)
    },
    watch: {
        activeKey(value) {
            let playerStr = value === "real" ? "recordPlayer" : "realPlayer";
            // 当菜单发生变化，应该关闭视频
            this.$refs[playerStr].close();
        }
    }
}
</script>

<style lang="less">
.wsplayer-demo-main-wrapper {
    height: 100%;

    .wsplayer-demo-wrapper {
        height: 100%;

        .logo {
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-size: 20px;
        }

        .right-video-wrapper {
            //height: calc(100% - 40px);
            height: 100%;
            flex: 1;
        }
    }

    .wsplayer-demo-wrapper-header {
        display: flex;
        justify-content: space-between;
    }

    .login {
        display: inline-block;
        margin-left: 16px;
        /* float: right;  */
        color: #a6acb3;
    }

    .login:hover {
        cursor: pointer;
    }

    .operation-content{
        display: flex;
        margin: 30px;
        background: #FFF;
        height: calc(100% - 124px);
        width: calc(100% - 60px);
    }

    .operation-content-left{
        display: flex;
        flex-direction: column;
        border-right: 1px solid #e9ebee;
    }

    .right-video-tabs{
        margin: 13px 20px 0;
        height: calc(100% - 13px);
    }

    .ant-tabs-content{
        height: 100%;
    }
}

</style>
