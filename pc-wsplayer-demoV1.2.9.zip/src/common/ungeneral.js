export const transformData = (tree) => {
    const arr = [];
    if (!!tree && tree.length !== 0) {
        tree.map((item) => {
            const obj = {};
            obj.title = item.name;
            obj.key = item.id;
            obj.value = item.id;
            obj.checked = item.checked;
            obj.children = transformData(item.children); // 递归调用
            arr.push(obj);
        });
    }
    return arr;
}
export const getStartTime = (time) => {
    return parseInt(new Date(new Date(new Date(time).toLocaleDateString()).getTime()) / 1000)
}
export const getEndTime = (time) => {
    return parseInt(new Date(new Date(new Date(time).toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1) / 1000)
}
/**
* @method transformTozTreeFormat() 简单数据转化成ztree数据
* @param {Array} sNodes 需要转化的简单数据
*/
export const transformTozTreeFormat = (sNodes) => {
    const childKey = "children";
    let treeData = [], expandedIdKeys = []
    if (!Array.isArray(sNodes)) return [];
    if (Object.prototype.toString.apply(sNodes) === "[object Array]") {
        const r = [];
        const tmpMap = {};
        for (let i = 0, l = sNodes.length; i < l; i++) {
            const { isParent, id: nodeId, name: nodeName, isCheck, pId, iconType, type, nodeType, isOnline } = sNodes[i] || {};
            tmpMap[nodeId] = sNodes[i];
            sNodes[i] = {
                ...sNodes[i],
                key: nodeId,
                value: nodeId,
                orgCode: nodeId,
                scopedSlots: { title: "title" },
                orgName: nodeName,
                isLeaf: !isParent,
                checkable: isCheck,
                iconPath: setIconPath(iconType, type, nodeType, isOnline)
            };
            if (tmpMap[pId] && nodeId !== pId) {
                if (!tmpMap[pId][childKey]) tmpMap[pId][childKey] = [];
                tmpMap[pId][childKey].push(sNodes[i]);
                !expandedIdKeys.includes(pId) && expandedIdKeys.push(pId)
            } else {
                r.push(sNodes[i]);
                !expandedIdKeys.includes(nodeId) && expandedIdKeys.push(nodeId)
            }
        }
        treeData = r.map(it => ({
            ...it,
            children: tmpMap[it.id][childKey]
        }));
        return {
            treeData,
            expandedIdKeys
        }
    }
    return { treeData: [sNodes] };
}
/**
 * 树节点的icon
 */
export function setIconPath(iconType, type, nodeType, isOnline) {
    let iconPath;
    if (iconType === '') {
        const icons = {
            'org': '/bResource/static/image/treeIcons/org_org_base',
            'ch': '/bResource/static/image/treeIcons/ch_default',
            'dev': '/bResource/static/image/treeIcons/dev_default'
        };

        if (icons[nodeType]) {
            iconPath = `${icons[nodeType]}${isOnline ? '_online' : ''}.png`;
        }
    } else {
        iconPath = `${iconType}${isOnline ? '_online' : ''}.png`
    }

    if(import.meta.env.VITE_NODE_ENV === 'wiki') {
        return `/evo-apigw/evo-image${iconPath}?proxyIp=${localStorage.proxyIp}`
    } else if(process.env.NODE_ENV === "development") {
        return `${window.location.protocol}//${localStorage.proxyIp}${iconPath}`
    }
    return `${window.location.protocol}//${window.location.host}${iconPath}`
}
/**
 * @method formatZtree() 简单数据转化成ztree数据
 * @param {Array} sNodes 需要转化的简单数据
 * @param {treeNodeType, treeNodeTypes, showCheckBoxTypes} checkConfig 接口中判断显示为选择框的条件配置
 * treeNodeType：筛选勾选框的字段类型
 * treeNodeTypes: 筛选勾选框的字段类型集合
 * showCheckBoxTypes: 显示勾选框的类型值
 */
export function formatZtree(sNodes, checkConfig = {}, selectableConfig = {}) {
    if (!Array.isArray(sNodes)) return [];
    const { treeNodeTypes = [], showCheckBoxTypes = {}, treeNodeType = '' } = checkConfig;
    const includeNodeTypes = [
        'objectType', 'nodeType', 'sourceType', ...treeNodeTypes
    ];
    const { selectableFields = [], selectableValues = {}, isthe = '1' } = selectableConfig;
    const childKey = "children";
    const tmpMap = {};
    for (let i = 0, l = sNodes.length; i < l; i++) {
        const { isParent, id: nodeId, name: nodeName, iconType, type, nodeType, isOnline } = sNodes[i] || {};
        let isCheckable = true;
        // 判断该节点是否显示勾选框
        if (treeNodeType) { // 单字段
            isCheckable = showCheckBoxTypes[sNodes[i][treeNodeType]];
        } else {
            const nodeTypes = Array.from(new Set(includeNodeTypes));
            isCheckable = nodeTypes.some(it => showCheckBoxTypes[sNodes[i][it]]);
        }
        let isSelectable = true;
        // 判断该节点是否能勾选
        if (selectableFields.length > 0) {
            const boo = selectableFields.some(it => selectableValues[sNodes[i][it]]);
            isSelectable = isthe === '1' ? boo : !boo;
        }
        sNodes[i] = {
            ...sNodes[i],
            key: nodeId,
            value: nodeId,
            orgCode: nodeId,
            orgName: nodeName,
            title: nodeName,
            isLeaf: !isParent,
            checkable: !!isCheckable,
            selectable: !!isSelectable,
            class: !isSelectable ? 'tree-no-selectable' : null,
            iconPath: setIconPath(iconType, type, nodeType, isOnline)
        };
        tmpMap[nodeId] = sNodes[i];
    }
    const tempArr = [];
    for (let i = 0, l = sNodes.length; i < l; i++) {
        const { id: nodeId, pId } = sNodes[i] || {};
        if (tmpMap[pId] && nodeId !== pId) {
            if (!tmpMap[pId][childKey]) tmpMap[pId][childKey] = [];
            tmpMap[pId][childKey].push(sNodes[i]);
        } else {
            tempArr.push(sNodes[i]);
        }
    }
    return tempArr.map(it => ({
        ...it,
        children: tmpMap[it.id][childKey]
    }));
}
/**
* @method saveFile() 导出
* @param {base64} data 导出的数据，待转
* @param {String} fileName 名称
* @param type 保存的文件类型,目前只有excel和zip
*/
export const saveFile = (data, fileName, type = 'excel') => {
    const ZIP = 'application/zip;charset=utf-8'
    const EXCEL = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8'
    const XML = "text/xml"
    let terminalType = ''
    if (type === 'excel') {
        terminalType = EXCEL
    } else if (type === 'zip') {
        terminalType = ZIP
    } else if (type === 'xml') {
        terminalType = XML
    }
    let blob = new Blob();
    if (typeof (data) === 'string') {
        let code = atob(data.replace(/\r\n/g, ''))
        let abuffer = new window.ArrayBuffer(code.length)
        let uBuffer = new window.Uint8Array(abuffer)
        for (let i = 0; i < code.length; i++) {
            uBuffer[i] = code.charCodeAt(i) & 0xff
        }
        blob = new Blob([uBuffer], {
            type: terminalType
        })
    } else {
        blob = new Blob([data], {
            type: terminalType
        })
    }
    if (window.navigator.msSaveOrOpenBlob) {
        // iE下使用msSaveBlob进行导出
        navigator.msSaveBlob(blob, fileName)
    } else {
        let href = window.URL.createObjectURL(blob)
        let save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a')
        save_link.href = href
        save_link.download = fileName
        // 解决火狐兼容问题
        document.body.appendChild(save_link)
        let event = document.createEvent('MouseEvents')
        event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
        save_link.dispatchEvent(event)
        document.body.removeChild(save_link)
        window.URL.revokeObjectURL(href)
    }
}


//原promise.allsettled在旧版本浏览器有不兼容问题
export function PromiseAllSettled(promiseArr) {
    return new Promise((resolve, reject) => {
        if (!Array.isArray(promiseArr)) {
            reject(new TypeError("arguments must be an array"))
        }

        const promiseLen = promiseArr.length;
        const res = [];
        let count = 0;
        for (let i = 0; i < promiseLen; i++) {
            Promise.resolve(promiseArr[i])
                .then((value) => {
                    res[i] = {
                        status: 'fulfilled',
                        value
                    }
                })
                .catch((reason) => {
                    res[i] = {
                        status: 'rejected',
                        reason
                    }
                })
                .finally(() => {
                    count++;
                    if (count == promiseLen) {
                        resolve(res)
                    }
                })
        }
    })
}
