/**
 * 网络请求通用方法
 * @example network.request({url:network.api.xxxurl,data:{},method:'post'}).then(res=>{}).catch(res=>{})
 */

import axios from "axios";
import qs from "qs";
// import { videoStore } from "../store/index";
import { urlRecast, getLocalLanguage, decodeObj, getBasePath } from './general';
// const store = videoStore();
/**
 * 接口请求通用方法
 * @param {String} url 接口地址 (是否必要:是)
 * @param {Number} urlType 如何拼接地址 不存在则用默认拼接; 1: host + url; 2: url (是否必要:否)
 * @param {String} method 接口请求类型 (是否必要:是)
 * @param {Boolean} isFormSubmit 是否为表单提交 (是否必要:否)
 * @param {String} responseType 响应类型 (是否必要:否)
 * @param {String} loadingText loading文字内容 (是否必要:否)
 * @param {Object} data 接口请求参数 (是否必要:否)
 * @param {String} contentType 请求参数格式 (是否必要:否)
 * @param {Object} headers 请求头 (是否必要:否)
 * @param {Number} timeout 超时时间 (是否必要:否)
 * @param {Boolean} checkToken 是否需要校验token，默认需要 (是否必要:否)
 * @param {Object} options 其他自定义参数 (是否必要:否)
 * @param {Boolean} isParseHtml 是否不需要转化转义字符 (是否必要:否)
 * @param {Boolean} isSNoTip   true说明成功的不需要弹提示，默认为false (是否必要:否)
 * @param {Boolean} isENoTip   true说明不需要错误的提示信息，默认为false (是否必要:否)
 * @param {String} eTipStr 错误时的提示 (是否必要:否)
 * @param {String} sTipStr 成功时的提示 (是否必要:否)
 * @param {Boolean} jumpLogin   是否跳转登录页 (是否必要:否)
 * @param {Boolean} returnDirectly   是否不做任何处理直接返回data或err (是否必要:否)
 *
 */
export async function request(config) {
    if (!config.url) {
        return Promise.reject("参数url不能为空。");
    }
    config.data = config.data || {};
    return await axiosRequest(config);
}

/**
 * @function 请求方法
 */
function axiosRequest(config) {
    // vue实例
    // const vueApp = window.vm.config.globalProperties

    // 获取最终url
    const url = urlRecast(config.url, config.urlType)

    // 语言
    let localLanguage = getLocalLanguage()
    if (localLanguage.includes('en')) {
        localLanguage = 'en-US'
    } else if (localLanguage.includes('zh')) {
        localLanguage = 'zh-CN'
    }

    // 请求客户端类型
    if (!localStorage.clientType) {
        localStorage.clientType = 1
    }

    return new Promise((resolve, reject) => {
        config.method = config.method.toLocaleLowerCase()
        const axiosConfig = {
            url,
            method: config.method,
            timeout: typeof config.timeout === 'number' ? config.timeout : 30000,
            responseType: config.responseType || "json",
            headers: {
                'user-client': localStorage.clientType,
                'Accept-Language': localLanguage,
                'Content-Type': config.contentType || (config.isFormSubmit ? 'application/x-www-form-urlencoded' : 'application/json;charset=utf-8'),
                'Authorization': config.checkToken !== false && localStorage.getItem("accessToken") ? 'bearer ' + localStorage.getItem("accessToken") : '',
                'timeOffset': new Date().getTimezoneOffset() * 60 * 1000,
                "proxyIp": localStorage['proxyIp'],
                ...config.headers
            },
            onUploadProgress: config.onUploadProgress,
            ...config.options,
        }
        config.method === "get" ? (axiosConfig.params = config.data) : (axiosConfig.data = config.data);

        // 表单提交
        if (axiosConfig.headers['Content-Type'].toLocaleLowerCase().includes('application/x-www-form-urlencoded')) {
            axiosConfig.data = qs.stringify(config.data)
        }

        // 请求拦截处理get转码问题
        axios.interceptors.request.use(function (config) {
            const paramsArr = []
            // get参数编码
            if (config.method === 'get' && config.params) {
                const keys = Object.keys(config.params)
                for (const key of keys) {
                    const value = config.params[key]
                    paramsArr.push(`${key}=${encodeURIComponent([null, undefined].includes(value) ? '' : value)}`)
                }
                config.params = {}
            }
            config.url = config.url + (paramsArr.length ? '?' + paramsArr.join('&') : '')
            return config
        }, function (error) {
            // 对请求错误做些什么
            return Promise.reject(error)
        });

        axios(axiosConfig).then(res => {
            if (config.returnDirectly) {
                resolve(res);
                return
            }

            const parseResult = config.isParseHtml ? res : decodeObj(res)
            const result = parseResult.data || {};
            const codeArgData = result.data || {}
            // i18n中配置的{0}数据，如密码错误3次，账号被锁定5分钟
            let codeArgArr = codeArgData.args ? codeArgData.args : codeArgData.value ? codeArgData.value : []
            const codeArg = codeArgArr[0]
            if (result.code === '0' || result.code === 1000 || result.success) {
                // 如果成功
                const data = result.data || '';
                // 成功消息
                // if (!config.isSNoTip) {
                //     const msg = config.sTipStr || "操作成功"
                //     // vueApp.$message.success(msg)
                // }
                resolve(data);
            } else if (result.code == '27001007') {
                const refreshToken = localStorage.getItem('refreshToken')

                // 如果存在refreshToken
                if (refreshToken !== 'undefined' && refreshToken) {
                    !window.refreshPromise && (window.refreshPromise = refreshTokenFn())
                    window.refreshPromise.then(() => {
                        axiosRequest(config).then(resRefresh => resolve(resRefresh)).catch(() => reject())
                    }).catch((err) => {
                        reject(err)
                    }).finally(() => {
                        window.refreshPromise = undefined;
                    })
                    return
                }

                // 客户端没有refreshtoken
                if (localStorage.clientType === '2') {
                    reject()
                    return
                }

            } else {
                // 其他情况为错误
                const err = result.code ? `error${result.code}` : 'ajaxDisconnect';
                const errMsg = config.eTipStr
                console.log(errMsg)
                // console.error(errMsg);
                if (!config.isENoTip) {
                    reject(errMsg);
                }
                reject(res);
            }
        }).catch(e => {
            console.error(e);

            // 设置跳转并为401
            if (!config.jumpLogin && e.response?.status === 401) {
                if (localStorage.clientType === '2' || localStorage.accessToken) {
                    console.log('/oauth/logout')
                    reject(e);
                    return
                }
            }

            if (e && e.response?.status === 431) {
                reject(e);
                return
            }

            // if (e && e.message === 'Network Error') {
            //     // vueApp.$message.warning("网络问题，请刷新后重试", 5)
            //     reject(e);
            //     return
            // }

            const cTime = new Date().getTime()
            const errorStatus = e.response?.status ? e.response.status : ''
            if ((cTime - localStorage.errorTime < 200) && !config.isENoTip) {
                localStorage.tError = 'serverError'
                reject(e);
                return
            }
            localStorage.errorTime = cTime

            const err = errorStatus ? `error${errorStatus}` : 'ajaxDisconnect';
            const errMsg = config.eTipStr || "网络异常"

            // if (!config.isENoTip) {
            //     reject(errMsg);
            //     // vueApp.$message.error(errMsg)
            // }

            reject(e);
        })
    })
}

/**
 * @function 刷新token接口
 */
export async function refreshTokenFn() {
    // vue实例
    // const vueApp = window.vm.config.globalProperties
    const refreshToken = localStorage.getItem('refreshToken')
    const clientId = localStorage.getItem('checked') ? 'web_client_remember' : 'web_client'
    const value = {
        'refresh_token': refreshToken,
        'grant_type': 'refresh_token',
        'client_id': clientId,
        "client_secret": 'web_client'
    }
    try {
        const res = await axios({
            url: '/evo-apigw/evo-oauth/oauth/token',
            method: 'post',
            headers: {
                // 'content-type': 'application/x-www-form-urlencoded',
                proxyIp: localStorage['proxyIp']
            },
            data: qs.stringify(value)
        })
        const result = res.data
        if (result.code === '0') {
            localStorage.setItem("accessToken", result.data.access_token)
            localStorage.setItem("refreshToken", result.data.refresh_token)
            localStorage.setItem('expiresTime', String(new Date().getTime() + result.data.expires_in * 1000))
            await keepAlive()
        } else {
            // import.meta.env.VITE_NODE_ENV === 'wiki' ? store.setLogin(true) : backToLogin()
            // throw new Error('权限失效，请重新登录')
        }
    } catch (error) {
        // 客户端没有refreshtoken
        if (localStorage.clientType === '2') {
            return
        }
        // if (vueApp.$route.path === '/login') {
        //     store.setLogin(true)
        // }
        // 用户信息失效，返回登录页
        return Promise.reject(error)
    }
}

/**
 * @function 保持认证信息
 */
export function keepAlive() {
    return axiosRequest({
        url: `evo-brm/1.2.0/user/keepalive`,
        method: 'post',
        isSNoTip: true,
        data: {
            clientType: 1,
            magicId: localStorage.magicId,
            timeout: 10000
        }
    })
}
/**
 * @function 用户信息失效，返回登录页
 */
export async function backToLogin(isSkip = false) {
    try {
        !isSkip && await axiosRequest({
            url: `evo-oauth/VERSION/oauth/logout`,
            method: 'get',
            isSNoTip: true,
        })

    } catch (error) {
        console.error(error);
    }

    localSClear(['UserName', 'checked', 'rememberToken', 'language', 'clientType']);
    top.location.href = getBasePath() + "#/login"
}
