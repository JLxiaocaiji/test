import { defineStore } from 'pinia'
export const videoStore = defineStore('store', {
    state: () => ({
        isLogin: import.meta.env.VITE_NODE_ENV === 'wiki' ? !localStorage['accessToken'] : false,
        selectedList: [], // 用于实时预览的通道节点
        checkedNodeList: [], // 用于录像回放的通道节点
        selectedWindow: null
    }),

    actions: {
        setLogin(params) {
            this.isLogin = params
        },
        setSelectedNode(nodeList) {
            this.selectedList = nodeList;
        },
        setCheckedNode(nodeList) {
            this.checkedNodeList = nodeList;
        },
        setSelectedWindow(params) {
            this.selectedWindow = params;
        }
    },
})
