<template>
    <div class='speed-select-wrapper'>
        <div class="disable-mask" v-if="isDisableSpeed"></div>
        <a-button type="text" @click="handleIt(false)" :disabled="isDisabledLeft">
            <img src="/static/svg/speed_left.svg" class="speed-icon" />
        </a-button>
        <span class="speed-text">{{speedText}}</span>
        <a-button type="text" @click="handleIt(true)" :disabled="isDisabledRight">
            <img src="/static/svg/speed_right.svg" class="speed-icon" />
        </a-button>
    </div>
</template>

<script>

export default {
    name: 'speedSelect',
    props: {
        speedText:{
            type: String,
            default() {
                return "1x"
            }
        },
        speedList:{
            type: Array,
            default() {
                return []
            }
        },
        isDisableSpeed:{
            type: Boolean,
            default() {
                return true;
            }
        },
    },
    data() {
        return {
        }
    },
    computed: {
        isDisabledLeft() {
            return this.speedText === this.speedList[0].label;
        },
        isDisabledRight() {
            return this.speedText === this.speedList[this.speedList.length - 1].label;
        },
    },
    methods: {
        handleIt(value) {
            this.$emit("setSpeed", value);
        }
    }
}
</script>
<style lang='less'>
.speed-select-wrapper{
    width: 160px;
    display: flex;
    position: relative;
    margin-right: 16px;
    .speedIcon{
        font-size: 22px;
    }
    .speed-text{
        line-height: 32px;
    }
    .ant-btn{
        margin:0 10px;
        min-width: 22px;
    }
    button[ant-click-animating-without-extra-node]:after {
        border: 0 none;
        opacity: 0;
        animation:none;
    }
    .disable-mask{
        height: 100%;
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        cursor: not-allowed;
        background-color: var(--placeholder);
        opacity: 0.2;
        z-index: 1;
    }

    .speed-icon{
        width: 20px;
        height: 20px;
    }
}
</style>
