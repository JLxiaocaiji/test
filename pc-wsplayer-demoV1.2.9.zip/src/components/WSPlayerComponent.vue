<template>
    <div class='ws-player-content'>
        <div v-if='type === "real"' class='player' ref='ws-real-player' id="ws-real-player" muted="muted"></div>
        <div v-if='type === "record"' class='player' ref='ws-record-player' id="ws-record-player" muted="muted"></div>
    </div>
</template>

<script setup name="wsplayer">
import {reactive, ref, toRaw, toRefs} from "@vue/reactivity";
import {getCurrentInstance} from 'vue'
import PlayerManager from '../icc/PlayerManager';
// import checkChromeV104Browser from '../../public/static/utils';
import {videoStore} from "../store/index";
// import speedSelect from './speedSelect.vue'
import dayjs from 'dayjs';

const vueApp = window.vm.config.globalProperties;
const store = videoStore();
const {ctx} = getCurrentInstance();
const _this = ctx;
const props = defineProps({
    type: { // 视频类型，real | record  默认为real
        type: String,
        default: "real"
    },
    checkedChannel: {
        type: Array,
        default() {
            return []
        }
    }
});
const emit = defineEmits(["realSuccess", "changePlayerNum", "closeVideoSuccess", "changeWindow"]);
//data
const {type, checkedChannel} = toRefs(props);
let playerManager = ref(null);
let playNum = ref(1);
let isPlay = ref(true);
let selectWindowIndex = ref(0);
let realTreeNodeList = ref([]); // 实时预览播放列表
let playbackTreeNodeList = ref([]); // 实时预览播放列表
let maxNum = ref(25)
let jumpTime = ref(dayjs().startOf("day"));



const treeNodeList = ref([]);
//监听更新设备节点播放录像
watch(
    () => store.selectedList,
    (newValue, oldValue) => {
        if(props.type === 'real') {
            let data = {
                method: 'setTreeNodeList',
                data: newValue
            }
            newValue && receive(data)
        }
    }
);
watch(
    () => store.selectedWindow,
    (newValue, oldValue) => {
        emit("setPtzChannel", newValue)
    }
);
/**
 * 初始化视频播放器
 */
const initPlayer = () => {
    // 如果已经创建了播放器，则不允许重复创建
    if(playerManager.player) {
        return;
    }
    playerManager = new PlayerManager({
        el: props.type === 'real'? 'ws-real-player' : 'ws-record-player', // 实时预览容器id
        pztEl: "ws-pan-tilt", // 云台控制容器id
        type: props.type, // real - 实时预览
        maxNum: maxNum.value, // 最多显示的窗口
        // rtspResponseTimeout: 8, // 测试不存在超时时长, 不传默认8s
        // prefixUrl: 'wsplayer/static', // 根据环境配置静态资源前缀
        num: 1, // 初始化显示的窗口
        showControl: true, // 默认是否显示工具栏
        useNginxProxy: window.location.protocol === 'https:' ? true : false, // 三方使用，请更改为 false，按照文档进行使用
        proxyServerIp: localStorage.proxyIp, // 三方使用请注释，按照文档来
        receiveMessageFromWSPlayer, // 接收来自wsplayer的回调
    })
    //清除已有list
    treeNodeList.value = [];
};
/**
 * 预览视频节点处理
 */
const getplay = (channelList, type) => {
    let list = props.type === 'real' ? realTreeNodeList.value : playbackTreeNodeList.value
    if(channelList.length > 1) {
        selectWindowIndex = 0
    }
    let tempChannelList = channelList.map((item, index) => {
        item.currentIndex = selectWindowIndex + index
        return item
    })
    let removeChannelList = []
    list = list.filter(item => {
        let cIndex = tempChannelList.findIndex(cItem => cItem.currentIndex === item.currentIndex)
        if(cIndex >= 0) {
            removeChannelList.push(item)
            return false
        }
        return true
    })
    realTreeNodeList.value = [...list, ...tempChannelList]
    // emit("realSuccess", channelList, list, removeChannelList)
};



/**
 * 设置显示的路数
 * @param e
 */
const setPlayerNum = (division) => {
    // playNum.value = division
    playerManager.player && playerManager.setPlayerNum(division);
};


/**
 * 设置屏幕自适应或者拉伸
 * @param {string} str selfAdaption 自适应 | stretching 拉伸
 */
const setPlayerAdapter = (str) => {
    playerManager.setPlayerAdapter(str);
};

/**
 * 关闭视频
 * @param snum 传入要关闭的窗口序号(不传则全部关闭)
 * 
 */
const close = (snum) => {
    playerManager.close(snum);
}





// ----------------- 实时预览 --------------------------------
/**
 * 播放某通道的实时视频
 * @param channelList：通道列表
 */
const realPlay = (channelList) => {
    treeNodeList.value.push(channelList.value);
    treeNodeList.value = [...new Set(treeNodeList.value)]
    playerManager.playRealVideo({
        channelList,
        // 默认用辅码流播放
        streamType: "2"
    })
    getplay(JSON.parse(JSON.stringify(channelList)), 'realTreeNodeList')
};

// ----------------- 录像回放 --------------------------------

/**
 * 录像回放
 * @param data
 */
const playRecordVideo = (data) => {
    // 将开始时间和结束时间转成时间戳（到秒）
    data.startTime = dayjs(data.startTime, "YYYY-MM-DD HH:mm:ss").format("X")
    data.endTime = dayjs(data.endTime, "YYYY-MM-DD HH:mm:ss").format("X")
    playerManager.playRecordVideo(data)
};


/**
 * 根据时间跳转播放
 */
const jumpPlayByTime = () => {
    playerManager.jumpPlayByTime(jumpTime.value.format("HH:mm:ss"));
};

/**
 * 设置选中的窗口索引
 */
const setSelectIndex = (index) => {
    selectWindowIndex = index;
    playerManager.setSelectIndex(index);
};

//批量触发操作
const receive = (data) => {
    switch(data.method) {
        case "playRecordVideo":
            playRecordVideo(data.data);
            break;
        // 批量实时预览
        case "setTreeNodeList":
            realPlay(data.data)
            break;
        case "setSelectIndex":
            setSelectIndex(data.data);
            break;
        default:
    }
};


/**
 * 接收来自无插件的回调
 * @param method
 * @param data
 */
const receiveMessageFromWSPlayer = (method, data, err) => {
    let nodeList = props.type === 'real' ? realTreeNodeList.value : playbackTreeNodeList.value
    switch(method) {
        case "initializationCompleted": // 初始化播放器成功
            console.log("初始化播放器成功");
            break;
        case "realSuccess": // 实时预览成功
            console.log("实时预览成功")
            break;
        case "realError":
            console.log("实时预览失败", err)
            break;
        case "recordSuccess": // 录像回放成功
            console.log("录像回放成功");
            break;
        case "recordSuccess": // 录像回放失败
            console.log("录像回放失败", err);
            break;
        case "talkError": // 对讲失败
            console.log("对讲失败");
            break;
        case "selectWindowChanged": // 切换窗口回调
            selectWindowIndex = data.playIndex
            break;
        case "windowNumChanged": // 显示窗口数量变化回调
            emit("changePlayerNum", data)
            break;
        case "statusChanged": // 窗口视频状态变化回调
            console.log(data, "视频状态打印")
            break;
        case "closeVideo": // 关闭视频
            // 非视频切换而引起的视频关闭，需要通知
            if(!data.changeVideoFlag) {
                let index = nodeList.findIndex(item => item.currentIndex === data.selectIndex)
                if(index > -1 && nodeList.filter(item => item.id === nodeList[index].id).length === 1) {
                    emit("closeVideoSuccess", [nodeList[index]], data.selectIndex)
                }
                nodeList.splice(index, 1)
            }
            break;
        case "errorInfo":
            vueApp.$message.error(data.errorInfo)
            console.error(data)
            break;
        default:
    }
};
defineExpose({
    receiveMessageFromWSPlayer, receive, close, initPlayer
});
onMounted(() => {
    initPlayer();
});
onUnmounted(() => {
    playerManager.player.setPlayerNum(1, false);
    playerManager.close(); // 关闭全部视频
})
</script>
<style lang="less">
.ws-player-content {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;

    .player:first-child {
        height: calc(100% - 20px);
    }

    .bottom-menu {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        height: 60px;
        flex-shrink: 0;

        > button {
            margin-right: 20px;
        }

        > i {
            font-size: 24px;
            margin-right: 20px;
        }

        .record-position {
            margin-right: 20px;
        }

        .wsIcon {
            font-size: 24px;
            margin-right: 16px;
        }

        .full-screen-icon{
            cursor: pointer;
        }
    }
}
</style>
