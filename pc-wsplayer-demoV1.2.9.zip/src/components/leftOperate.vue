<template>
    <div class="left-operate-wrapper">
        <div class="operate-title">操作台</div>
        <deviceTree :videoType="mode" class="deviceTree"/>
        <div class="operate-detail" v-if="mode==='record'">
            <div class="mg16">
                码流类型：
                <a-select v-model:value='streamType' style="width: 200px">
                    <a-select-option value="0">所有码流</a-select-option>
                    <a-select-option value="1">主码流</a-select-option>
                    <a-select-option value="2">辅码流1</a-select-option>
                    <a-select-option value="3">辅码流2</a-select-option>
                </a-select>
            </div>
            <div class="mg16">
                录像来源：
                <a-select v-model:value='recordSource' style="width: 200px">
                    <!--查询自动录像，V5.0.14版本才实现，自动的话默认优先查询服务器录像，不存在服务器录像才会查询录像机录像-->
                    <!--<a-select-option value="1">自动</a-select-option>-->
                    <a-select-option value="3">存储在服务器上的录像</a-select-option>
                    <a-select-option value="2">存储在录像机上的录像</a-select-option>
                </a-select>
            </div>
            <div class="time-picker-wrapper mg16">
                录像日期：
                <a-date-picker v-model:value="day" value-format="YYYY-MM-DD" format="YYYY-MM-DD" @change="timeChange" :allowClear="false"/>
                <div class="time">
                    <a-time-picker width="30px" v-model:value="startTime" value-format="HH:mm" format="HH:mm"
                                   @change="timeChange" :allowClear="false"/>
                    -
                    <a-time-picker v-model:value="endTime" value-format="HH:mm" format="HH:mm" @change="timeChange" :allowClear="false"/>
                </div>
            </div>
            <a-button type="primary" @click="searchRecord">查询</a-button>
        </div>
    </div>
</template>

<script setup name="leftOprate">
import deviceTree from './deviceTree.vue';
import dayjs from 'dayjs';
import {videoStore} from "../store/index";

const store = videoStore();

const vueApp = window.vm.config.globalProperties;
const props = defineProps({
    mode: {
        type: String,
        default: "real",
    }
});
const emit = defineEmits(["searchRecord"]);
const refreshTree = ref(true);
const day = ref(dayjs(new Date()).format("YYYY-MM-DD"));
const startTime = ref('00:00');
const endTime = ref('23:59');
let streamType = ref("0");
let recordSource = ref("3");
let recordBeginTime = ref(day.value + " " + startTime.value + ":00");
let recordEndTime = ref(day.value + " " + endTime.value + ":59");
//初始化云台
const panTilt = ref();
//改变时间
const timeChange = (time, timeString) => {
    const beginTimes = day.value + " " + startTime.value + ":00";
    const endTimes = day.value + " " + endTime.value + ":59";
    const timeDiff = dayjs(endTimes).diff(dayjs(beginTimes))
    if(timeDiff <= 0) {
        vueApp.$message.warning("结束时间不得大于开始时间，请重新选择！")
        return
    }
    recordBeginTime.value = beginTimes;
    recordEndTime.value = endTimes;
};
const searchRecord = () => {
    if(!store.checkedNodeList.length) {
        vueApp.$message.warning("请选择视频通道")
        return
    }
    let data = {
        channelList: store.checkedNodeList,
        startTime: recordBeginTime.value,
        endTime: recordEndTime.value,
        recordSource: recordSource.value,
        streamType: streamType.value
    };
    emit("searchRecord", data)
}
</script>

<style lang="less">
.left-operate-wrapper {
    min-width: 300px;
    border-bottom: 1px solid #e9ebee;
    height: calc(100% - 244px);

    .mg16 {
        margin-bottom: 16px;
    }

    .operate-title {
        padding: 0 20px;
        font-size: 16px;
        font-weight: 600;
        line-height: 60px;
        border-bottom: 1px solid #e9ebee;
    }

    .operate-detail {
        margin-top: 20px;
        padding-left: 10px;
        // border-bottom: 1px solid #e9ebee;
        .time-picker-wrapper {
            // margin: 20px 0;
            .time {
                margin-top: 10px;

                .ant-picker {
                    width: 100px;
                }
            }
        }
    }
}
</style>
