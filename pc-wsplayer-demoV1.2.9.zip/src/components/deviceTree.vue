<template>
    <div class="device-tree-wrapper">
        <a-spin tip="Loading..." :spinning="departmentLoading">
            <a-input-search v-model="searchValue" placeholder="请输入设备名称" @search="search" />
            <a-tree
                :load-data="onLoadData"
                :tree-data="deviceTreeData"
                :expandedKeys="expandedKeys"
                :selectedKeys="selectedKeysVal"
                :checkedKeys="checkedKeysVal"
                :loadedKeys="loadedKeys"
                @expand="onExpand"
                class="treeView"
                :class="[videoType !== 'record' ? 'realTree' : 'recordTree']"
                :checkable="videoType === 'record'"
                @select="treeSelect"
                @check="onCheckNodes"
            >
                <template #title="{ name, iconPath, afterIcon }">
                    <span>
                        <img :src="iconPath" class="iconImg" />
                        <span style="padding-left: 4px">{{ name }}</span>
                        <img v-if="afterIcon" :src="afterIcon" class="after-icon" />
                    </span>
                </template>
            </a-tree>
        </a-spin>
    </div>
</template>

<script setup name="deviceTree">
import factory from "../factory";
import { transformTozTreeFormat, setIconPath, getStartTime, getEndTime } from "../common/ungeneral";
import { videoStore } from "../store/index";
import { reactive, ref, toRaw, toRefs } from "@vue/reactivity";
const props = defineProps({
    videoType: {
        type: String,
        default: "real",
    },
});
const { videoType } = toRefs(props);
const store = videoStore();
const searchValue = ref("");
let selectedNodes1 = ref([]);
let selectedKeysVal = ref([]);
let checkedKeysVal = ref([]);
let deviceTreeData = ref([]);
let loadedKeys = ref([]);
let isDevTree = ref(false);
let departmentLoading = ref(false);
let params = reactive({
    checkStat: 1,
    showEmptyOrgNode: 0,
    type: "001;;1",
});
let expandedKeys = ref([]);

const emit = defineEmits(["playVideo"]);
//监听登录后刷新设备树
watch(
    () => store.isLogin,
    (newValue, oldValue) => {
        newValue && getDeviceTree();
    }
);

//节点展开、收起控制expandedKeys
const onExpand = (keys) => {
    expandedKeys.value = keys
}
const search = (val) => {
    searchValue.value = val
    if (searchValue.value) {
        params = {
            checkStat: 1,
            showEmptyOrgNode: 0,
            type: "001;;1",
            act: "search",
            searchKey: searchValue.value,
        };
    } else {
        params = {
            checkStat: 1,
            showEmptyOrgNode: 0,
            type: "001;;1",
        };
    }
    getDeviceTree();
};

/**
 * 选择树节点，用于实时预览
 * @param selectedKeys
 * @param $event
 */
const treeSelect = (selectedKeys, $event) => {
    selectedKeysVal.value = [];
    isDevTree.value = false;
    let { selected, selectedNodes } = $event;
    if (selected && selectedNodes[0].nodeType === "ch") {
        selectedKeysVal.value = selectedKeys;
        selectedNodes1.value = [selectedNodes[0]]
        store.setSelectedNode(selectedNodes)
    } else if (selected && selectedNodes[0].nodeType === "dev") {
        if(selectedNodes[0].children){
            store.setSelectedNode([...selectedNodes[0].children])
        } else {
            expandedKeys.value.push(selectedNodes[0].id)
            expandedKeys.value = [...new Set(expandedKeys.value)];
            isDevTree.value = true;
        }
    } else {
        store.setSelectedNode(null)
    }
};

/**
 * 多选框勾选节点，用于录像回放
 * @param checkedKeys
 * @param $event
 */
const onCheckNodes = (checkedKeys, $event) => {
    let { checked, node, checkedNodes } = $event;
    checkedKeysVal.value = checkedKeys;
    // 如果勾选的是设备，则需要查询出通道
    if(checked && node.nodeType === "dev" && !node.children) {
        onLoadData(node, true)
    }
    store.setCheckedNode(checkedNodes.filter(node => node.nodeType === "ch"));
}

/**
 * 异步加载树节点
 * @param treeNode 父节点
 * @param manualType 手动加载标志
 * @returns {Promise<unknown>}
 */
const onLoadData = (treeNode, manualType = false) => {
    const { id, name } = treeNode.dataRef;
    let param = { ...params, id: id };
    departmentLoading.value = true;
    return new Promise((resolve) => {
        factory
            .getDeviceData(param)
            .then((res) => {
                if(treeNode.dataRef.nodeType === "dev" && isDevTree.value) {
                    store.setSelectedNode(res.value)
                }
                isDevTree.value = false
                let val = res.value;
                expandedKeys.value.push(id);
                loadedKeys.value.push(id)
                expandedKeys.value = [...new Set(expandedKeys.value)];
                loadedKeys.value.push(...val);
                val.forEach((item) => {
                    item.isLeaf = !item.isParent;
                    item.parentName = name;
                    item.key = item.id;
                    item.iconPath = setIconPath(item.iconType, item.type, item.nodeType, item.isOnline);
                    item.checkable = item.nodeType === "dev" || item.nodeType === "ch";
                });
                treeNode.dataRef.children = val;
                deviceTreeData.value = [...deviceTreeData.value];
                if(manualType) {
                    if(videoType.value === "record") {
                        store.setCheckedNode(store.checkedNodeList.concat(res.value));
                    }
                }
                resolve();
            })
            .finally(() => {
                departmentLoading.value = false;
            });
    });
};
const getDeviceTree = async () => {
    isDevTree.value = false;
    const deviceTree = await factory.getDeviceData(params);
    loadedKeys.value = [...deviceTree.value]
    if (deviceTree) {
        deviceTreeData.value = []
        expandedKeys.value = []
        const {treeData, expandedIdKeys} = transformTozTreeFormat(deviceTree.value);
        console.log("加载节点", expandedIdKeys)
        deviceTreeData.value = treeData
        expandedKeys.value = expandedIdKeys

    }
};
onMounted(() => {
    getDeviceTree();
});
</script>

<style lang="less">
.device-tree-wrapper {
    height:calc(100% - 66px);
    width: 300px;
    padding: 10px;
    position: relative;
    .apiBtn {
        position: absolute;
        top: 0;
        left: -40px;
        writing-mode: vertical-rl;
        background-color: #1890ff;
        color: #fff;
        padding: 10px 5px;
        border-radius: 4px;
        cursor: pointer;
    }
    .ant-tree .ant-tree-node-content-wrapper {
        vertical-align: middle;
        cursor: pointer;
        white-space: nowrap;
    }
    .ant-spin-nested-loading{
        height: 100%;
        .ant-spin-container{
            height: 100%;
        }
    }
    .recordTree {
        height: calc(100% - 52px);
        overflow: auto;
        margin-top: 20px;
    }
    .realTree {
        height: calc(100% - 52px);
        overflow: auto;
        margin-top: 20px;
    }
}
</style>
