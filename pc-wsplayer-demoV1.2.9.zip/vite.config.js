import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path, { resolve } from 'path'
import AutoImport from 'unplugin-auto-import/vite'
import resolveExternalsPlugin from 'vite-plugin-resolve-externals'
import basicSsl from '@vitejs/plugin-basic-ssl'
import serverConfig from "./config/config";
import legacy from '@vitejs/plugin-legacy'
import topLevelAwait from 'vite-plugin-top-level-await'
// https://vitejs.dev/config/
export default defineConfig({
  base: "/wsplayer/",
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    }
  },

  plugins: [
    vue(),
    resolveExternalsPlugin({
      WSPlayer: 'WSPlayer',
      'jquery': 'jQuery', // 这个名字可以直接打印window，看window上挂的是什么名字，就写什么名字
    }),
    //传统浏览器兼容性支持--需要支持的放开注释即可
    legacy({
      targets: ['chrome >= 56', 'IE >= 11', 'Firefox >= 70', 'Edge >= 44'],
      additionalLegacyPolyfills: ['regenerator-runtime/runtime'],
      modernPolyfills: true
    }),
    // 配置最顶层使用 await
    topLevelAwait({
        // The export name of top-level await promise for each chunk module
        promiseExportName: '__tla',
        // The function to generate import names of top-level await promise in each chunk module
        promiseImportName: i => `__tla_${i}`
    }),
    AutoImport({
      imports: ["vue"], // 自动导入vue和vue-i18n相关函数
      dts: "src/@types/auto-import.d.ts" // 生成 `auto-import.d.ts` 全局声明
    }),
    basicSsl()
  ],
  server: {
    host: '0.0.0.0',
    headers: {
        "Cross-Origin-Embedder-Policy": "credentialless",
        "Cross-Origin-Opener-Policy": "same-origin"
    },
    https: true,
    proxy: {
      '/evo-websocket/**': {
        // target: 'wss://10.35.239.51',
        target: `wss://${serverConfig.ip}`,
        ws: true,
        secure: false,
      },
      '/evo-apigw': {
        target: `https://${serverConfig.ip}/`,
        secure: false,
        pathRewrite: { // 请求路径重写
          '/evo-apigw': '/evo-apigw',   //重写请求路径
        },
      }
    },
    watch: {
      usePolling: true
    }
  },
})
